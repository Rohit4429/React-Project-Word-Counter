import React from 'react'
import { useState } from 'react';
import LanguageDetector from 'i18next-browser-languagedetector';

export default function WordCounter(props) {
  
const [text, setText] = useState('Hey! Write Somethis else...')
    const HandleUpClick = () =>{
        let newText = text.toUpperCase();
        setText(newText);
    }
    const HandleLoClick = () =>{
        let newText = text.toLowerCase();
        setText(newText);
    }
    const HandleOnChange = (e) =>{
        setText(e.target.value);
    }
  return (
    <div className='container py-5'>
        <h3>{props.title}</h3>
       <textarea name="name" id="word" value={text} onChange={HandleOnChange} className='form-control my-4' cols="30" rows="10"></textarea>
       <button className='btn btn-primary mx-2' onClick={HandleUpClick}>Click To Uppercase</button>
       <button className='btn btn-primary mx-2' onClick={HandleLoClick}>Click To lowercase</button>
       <div className='alert alert-danger mt-5'>
        <p>Total Char: {text.length} and Total Words: {text.split(" ").length}</p>
       </div>
    </div>
  )
}
