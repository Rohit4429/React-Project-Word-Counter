 
import './App.css';
import WordCounter from './components/WordCounter';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
function App() {
  return (
     <>
     <WordCounter title="Write Your Text Here..!"/>
     </>
  );
}

export default App;
